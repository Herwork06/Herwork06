from urllib import request
import zipfile, os



URL = "https://github.com/hisprofile/TF2-Trifecta/releases/download/v1.3/TF2-Trifecta.zip"
filename = "newUpdate.zip"
filePath = "temp/newUpdate.zip"

response = request.urlretrieve(URL, filePath)



with zipfile.ZipFile(filePath, "r") as zip_ref:
    zip_ref.extractall(path="C:\\Program Files\\Blender Foundation\\Blender 3.3\\3.3\scripts\\addons")


